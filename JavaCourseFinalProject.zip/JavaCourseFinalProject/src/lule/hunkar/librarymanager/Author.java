package lule.hunkar.librarymanager;

import java.time.LocalDate;

/**
 * Class for Author objects. It extends Person class. Class has two fields for
 * pseudonym and specialty. It overrides equals class. If two author objects
 * have same pseudonym and specialty then they are equals.
 * 
 * @author Hunkar Lule
 *
 */
public class Author extends Person {
	private String pseudonym;
	private Genre specialty;

	/**
	 * @param firstName
	 *            string first name
	 * @param lastName
	 *            string last name
	 * @param dateOfBirth
	 *            Localdate birth of date
	 * @param pseudonym
	 *            string pseudonym
	 * @param specialty
	 *            enum specialty
	 * 
	 *            Construts an author object with specified first name, last name,
	 *            date of birth, pseudonym and speciality.
	 */
	public Author(String firstName, String lastName, LocalDate dateOfBirth, String pseudonym, Genre specialty) {
		super(firstName, lastName, dateOfBirth);
		setPseudonym(pseudonym);
		setSpecialty(specialty);
	}

	/**
	 * @return the pseudonym
	 */
	public final String getPseudonym() {
		return pseudonym;
	}

	/**
	 * @param pseudonym
	 *            the pseudonym to set
	 */
	public final void setPseudonym(String pseudonym) {
		this.pseudonym = pseudonym;
	}

	/**
	 * @return the specialty
	 */
	public final Genre getSpecialty() {
		return specialty;
	}

	/**
	 * @param specialty
	 *            the specialty to set
	 */
	public final void setSpecialty(Genre specialty) {
		this.specialty = specialty;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((pseudonym == null) ? 0 : pseudonym.hashCode());
		result = prime * result + ((specialty == null) ? 0 : specialty.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (!(obj instanceof Author))
			return false;
		Author other = (Author) obj;
		if (pseudonym == null) {
			if (other.pseudonym != null)
				return false;
		} else if (!pseudonym.equals(other.pseudonym))
			return false;
		if (specialty != other.specialty)
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Author [pseudonym=" + pseudonym + ", specialty=" + specialty + ", toString()=" + super.toString() + "]";
	}

}
