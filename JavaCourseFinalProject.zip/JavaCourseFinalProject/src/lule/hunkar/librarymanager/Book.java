package lule.hunkar.librarymanager;

/**
 * Book class to book objects. Class override equals and hascode methods. Alos
 * implements Comparable interface to compare books with edition.
 * 
 * @author Hunkar Lule
 *
 */
public class Book implements Comparable<Book> {
	private String title;
	private Author author;
	private int yearPublished;
	private int edition;
	private String ISBN;
	private Genre genre;
	private int numberOfCopies;
	private int numberOfAvailableCopies;

	/**
	 * Constructs book objects with specified attributes.
	 * 
	 * @param title
	 *            string book title
	 * @param author
	 *            author object
	 * @param yearPublished
	 *            int book publised year
	 * @param edition
	 *            int book edition
	 * @param iSBN
	 *            int book ISBN
	 * @param genre
	 *            enum book genre
	 * @param numberOfCopies
	 *            int number of book copies
	 * @param numberOfAvailableCopies
	 *            int number of book available copies
	 */
	public Book(String title, Author author, int yearPublished, int edition, String iSBN, Genre genre,
			int numberOfCopies, int numberOfAvailableCopies) {
		super();
		setTitle(title);
		setAuthor(author);
		setYearPublished(yearPublished);
		setEdition(edition);
		setISBN(iSBN);
		setGenre(genre);
		setNumberOfCopies(numberOfCopies);
		setNumberOfAvailableCopies(numberOfAvailableCopies);
	}

	/**
	 * @return the title
	 */
	public final String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public final void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the author
	 */
	public final Author getAuthor() {
		return author;
	}

	/**
	 * @param author
	 *            the author to set
	 */
	public final void setAuthor(Author author) {
		this.author = author;
	}

	/**
	 * @return the yearPublished
	 */
	public final int getYearPublished() {
		return yearPublished;
	}

	/**
	 * @param yearPublished
	 *            the yearPublished to set
	 */
	public final void setYearPublished(int yearPublished) {
		this.yearPublished = yearPublished;
	}

	/**
	 * @return the edition
	 */
	public final int getEdition() {
		return edition;
	}

	/**
	 * @param edition
	 *            the edition to set
	 */
	public final void setEdition(int edition) {
		this.edition = edition;
	}

	/**
	 * @return the iSBN
	 */
	public final String getISBN() {
		return ISBN;
	}

	/**
	 * @param iSBN
	 *            the iSBN to set
	 */
	public final void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	/**
	 * @return the genre
	 */
	public final Genre getGenre() {
		return genre;
	}

	/**
	 * @param genre
	 *            the genre to set
	 */
	public final void setGenre(Genre genre) {
		this.genre = genre;
	}

	/**
	 * @return the numberOfCopies
	 */
	public final int getNumberOfCopies() {
		return numberOfCopies;
	}

	/**
	 * @param numberOfCopies
	 *            the numberOfCopies to set
	 */
	public final void setNumberOfCopies(int numberOfCopies) {
		this.numberOfCopies = numberOfCopies;
	}

	/**
	 * @return the numberOfAvailableCopies
	 */
	public final int getNumberOfAvailableCopies() {
		return numberOfAvailableCopies;
	}

	/**
	 * @param numberOfAvailableCopies
	 *            the numberOfAvailableCopies to set
	 */
	public final void setNumberOfAvailableCopies(int numberOfAvailableCopies) {
		this.numberOfAvailableCopies = numberOfAvailableCopies;
	}

	public final void increaseNumberOfAvailableCopies() {
		this.numberOfAvailableCopies++;
	}

	public final void decreaseNumberOfAvailableCopies() {
		this.numberOfAvailableCopies--;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Book [title=" + title + ", author=" + author + ", yearPublished=" + yearPublished + ", edition="
				+ edition + ", ISBN=" + ISBN + ", genre=" + genre + ", numberOfCopies=" + numberOfCopies
				+ ", numberOfAvailableCopies=" + numberOfAvailableCopies + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		result = prime * result + edition;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Book)) {
			return false;
		}
		Book other = (Book) obj;
		if (author == null) {
			if (other.author != null) {
				return false;
			}
		} else if (!author.equals(other.author)) {
			return false;
		}
		if (edition != other.edition) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(Book book) {
		return this.getEdition() - book.getEdition();
	}
}
