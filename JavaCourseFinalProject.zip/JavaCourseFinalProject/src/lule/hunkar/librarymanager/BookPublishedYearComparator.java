package lule.hunkar.librarymanager;

import java.util.Comparator;

/**
 * Comparator to compare two books object according to published year. The book
 * with newest published year is bigger.
 * 
 * @author Hunkar Lule
 * 
 */
public class BookPublishedYearComparator implements Comparator<Book> {
	@Override
	public int compare(Book book1, Book book2) {
		return book1.getYearPublished() - book2.getYearPublished();
	}
}
