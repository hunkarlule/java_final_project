package lule.hunkar.librarymanager;

import java.time.LocalDate;

/**
 * Borrowing class for borrowing objects.
 * 
 * @author Hunkar Lule
 *
 */
public class Borrowing {
	private Book book;
	private Customer customer;
	private boolean finished;
	private LocalDate borrowedDate;
	private LocalDate returnDate;

	/**
	 * Constructor to construct Borrowing objects with specified attributes.
	 * 
	 * @param book
	 *            book object
	 * @param customer
	 *            customer object
	 * @param finished
	 *            boolean to determine borrowing is finished
	 * @param borrowedDate
	 *            local date book borrowing date
	 * @param returnDate
	 *            local date book expected return date
	 */
	public Borrowing(Book book, Customer customer, boolean finished, LocalDate borrowedDate, LocalDate returnDate) {
		super();
		setBook(book);
		setCustomer(customer);
		setBorrowedDate(borrowedDate);
		setFinished(finished);
		setReturnDate(returnDate);
	}

	/**
	 * @return the book
	 */
	public final Book getBook() {
		return book;
	}

	/**
	 * @param book
	 *            the books to set
	 */
	public final void setBook(Book book) {
		this.book = book;
	}

	/**
	 * @return the customer
	 */
	public final Customer getCustomer() {
		return customer;
	}

	/**
	 * @param customer
	 *            the customer to set
	 */
	public final void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/**
	 * @return the finished
	 */
	public final boolean isFinished() {
		return finished;
	}

	/**
	 * @param finished
	 *            the finished to set
	 */
	public final void setFinished(boolean finished) {
		this.finished = finished;
	}

	/**
	 * @return the borrowedDate
	 */
	public final LocalDate getBorrowedDate() {
		return borrowedDate;
	}

	/**
	 * @param borrowedDate
	 *            the borrowedDate to set
	 */
	public final void setBorrowedDate(LocalDate borrowedDate) {
		this.borrowedDate = borrowedDate;
	}

	/**
	 * @return the returnDate
	 */
	public final LocalDate getReturnDate() {
		return returnDate;
	}

	/**
	 * @param returnDate
	 *            the returnDate to set
	 */
	public final void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Borrowing [book=" + book + ", customer=" + customer + ", finished=" + finished + ", borrowedDate="
				+ borrowedDate + ", returnDate=" + returnDate + "]";
	}

}
