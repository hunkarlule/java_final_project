package lule.hunkar.librarymanager;

import java.time.LocalDate;

/**
 * Class for Customer objects. It extends Person class. Class has three fields
 * for customer id, customer status and number of borrowed books.
 * 
 * @author Hunkar Lule
 *
 */
public class Customer extends Person {
	private String customerId;
	private boolean isActive;
	private int numberOfBorrowedBooks;

	/**
	 * Constructs a customer object with specified first name, last name, date of
	 * birth, customer id , customer status and number of borrowed books.
	 * 
	 * @param firstName
	 *            string customer first name
	 * @param lastName
	 *            string customer last name
	 * @param dateOfBirth
	 *            localdate customer date of birth
	 * @param customerId
	 *            string customer id
	 * @param isActive
	 *            boolean to determine customer is active or not
	 * @param numberOfBorrowedBooks
	 *            int number of books customer holds currently
	 */
	public Customer(String firstName, String lastName, LocalDate dateOfBirth, String customerId, boolean isActive,
			int numberOfBorrowedBooks) {
		super(firstName, lastName, dateOfBirth);
		setCustomerId(customerId);
		setActive(isActive);
		setNumberOfBorrowedBooks(numberOfBorrowedBooks);
	}

	/**
	 * @return the customerId
	 */
	public final String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public final void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the isActive
	 */
	public final boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive
	 *            the isActive to set
	 */
	public final void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the numberOfBorrowedBooks
	 */
	public final int getNumberOfBorrowedBooks() {
		return numberOfBorrowedBooks;
	}

	/**
	 * @param numberOfBorrowedBooks
	 *            the numberOfBorrowedBooks to set
	 */
	public final void setNumberOfBorrowedBooks(int numberOfBorrowedBooks) {
		this.numberOfBorrowedBooks = numberOfBorrowedBooks;
	}

	public final void increaseNumberOfBorrowedBooks() {
		this.numberOfBorrowedBooks++;
	}

	public final void decreaseNumberOfBorrowedBooks() {
		this.numberOfBorrowedBooks--;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", isActive=" + isActive + ", numberOfBorrowedBooks="
				+ numberOfBorrowedBooks + ", toString()=" + super.toString() + "]";
	}

}
