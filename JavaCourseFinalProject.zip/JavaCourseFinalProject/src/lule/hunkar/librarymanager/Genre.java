package lule.hunkar.librarymanager;

import java.util.Arrays;

/**
 * Enum to hold book genres and author specialities.
 * 
 * @author Hunkar Lule
 *
 */
public enum Genre {
	FICTION, NON_FICTION, SCI_FI, BIOGRAPHY, HISTORY, CHILDREN;

	public static String genresString() {
		return Arrays.toString(Genre.values());
	}

}
