package lule.hunkar.librarymanager;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Class for library objects. Class has fields to hold custormers, books and
 * borrowed books with bunch of methods to add, remove books, to add customers,
 * to borrw and return books etc.
 * 
 * @author Hunkar Lule
 *
 */
public class Library {
	public final static String LIBRARY_NAME = "Vancouver Public Library";
	public final static int CUSTOMER_BOOK_BOORWING_LIMIT = 5;
	public final static int ALLOWED_BORROWING_DURATION = 15;
	private String libraryName;
	private HashMap<String, Book> bookCatalogue;
	private HashMap<String, Customer> customerCatalogue;
	private ArrayList<Borrowing> borrowedBooks;

	/**
	 * Constructor that intialize the fields with default values.
	 */
	public Library() {
		libraryName = LIBRARY_NAME;
		bookCatalogue = new HashMap<String, Book>();
		customerCatalogue = new HashMap<String, Customer>();
		borrowedBooks = new ArrayList<Borrowing>();
	}

	/**
	 * @return the libraryName
	 */
	public final String getLibraryName() {
		return libraryName;
	}

	/**
	 * @return the bookCatalogue
	 */
	public final HashMap<String, Book> getBookCatalogue() {
		return bookCatalogue;
	}

	/**
	 * @return the customerCatalogue
	 */
	public final HashMap<String, Customer> getCustomerCatalogue() {
		return customerCatalogue;
	}

	/**
	 * @return the borrowedBooks
	 */
	public final ArrayList<Borrowing> getBorrowedBooks() {
		return borrowedBooks;
	}

	/**
	 * Method to display the books in the library according to sorting choice
	 * 
	 * @param sortingChoice
	 *            string to determine sorting choice.
	 */
	public void displayBookCataloque(String sortingChoice) {
		List<Book> books = new ArrayList<Book>(bookCatalogue.values());
		if (sortingChoice.equalsIgnoreCase("E")) {
			Collections.sort(books);
		} else if (sortingChoice.equalsIgnoreCase("Y")) {
			Collections.sort(books, new BookPublishedYearComparator());
		}

		System.out.printf("%-40s%-25s%-25s%12s%10s%5s%-10s%-15s%10s%5s%10s%n", "Title", "A.First Name", "A.Last Name",
				"Publish Year", "Edition", "", "ISBN", "Genre", "T.Copies", "", "A.Copies");
		OutputWriter.printText(
				"-----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		for (Book book : books) {
			System.out.printf("%-40s%-25s%-25s%12d%10d%5s%-10s%-15s%10d%5s%10d%n", book.getTitle(),
					book.getAuthor().getFirstName(), book.getAuthor().getLastName(), book.getYearPublished(),
					book.getEdition(), "", book.getISBN(), book.getGenre(), book.getNumberOfCopies(), "",
					book.getNumberOfAvailableCopies());
		}
		OutputWriter.printText(
				"-----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	}

	/**
	 * Method to display the customers in the library.
	 */
	public void displayCustomerCatalogue() {
		System.out.printf("%-15s%-25s%-25s%-15s%-10s%-12s%n", "Customer Id", "C.First Name", "C.Last Name",
				"Birth Date", "Active", "# of B.Books");
		OutputWriter.printText(
				"------------------------------------------------------------------------------------------------------");

		for (Customer customer : customerCatalogue.values()) {
			System.out.printf("%-15s%-25s%-25s%-15s%-10s%12s%n", customer.getCustomerId(), customer.getFirstName(),
					customer.getLastName(), customer.getDateOfBirth(), customer.isActive(),
					customer.getNumberOfBorrowedBooks());
		}
		OutputWriter.printText(
				"------------------------------------------------------------------------------------------------------");
	}

	/**
	 * Method to display the borrowed books in the library.
	 */
	public void displayBorrowings() {
		System.out.printf("%-15s%-25s%-25s%-40s%-10s%-20s%-20s%-10s%n", "Customer Id", "C.First Name", "C.Last Name",
				"Title", "ISBN", "Borrowing Date", "Return Date", "Finished");
		OutputWriter.printText(
				"-------------------------------------------------------------------------------------------------------------------------------------------------------------------");

		for (Borrowing borrowing : borrowedBooks) {

			System.out.printf("%-15s%-25s%-25s%-40s%-10s%-20s%-20s%-10s%n", borrowing.getCustomer().getCustomerId(),
					borrowing.getCustomer().getFirstName(), borrowing.getCustomer().getLastName(),
					borrowing.getBook().getTitle(), borrowing.getBook().getISBN(), borrowing.getBorrowedDate(),
					borrowing.getReturnDate(), borrowing.isFinished());
		}
		OutputWriter.printText(
				"-------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	}

	/**
	 * Method to add a new customer to library. Method takes a customer object as
	 * parameter and add to customer catalogue.
	 * 
	 * @param customer
	 *            customer object
	 */
	public void addCustomer(Customer customer) {
		this.customerCatalogue.put(customer.getCustomerId(), customer);
		OutputWriter.printText("Customer " + customer.getCustomerId() + " is succesfully added!");
	}

	/**
	 * Method to inactivate a customer. Method takes a custome id string parameter
	 * and inactivate the customer with that id.
	 * 
	 * @param customerId
	 *            string customer id
	 */
	public void inactivateCustomer(String customerId) {
		// Customer customer = null;
		Customer customer = this.customerCatalogue.get(customerId);
		if (customer.isActive()) {
			if (customer.getNumberOfBorrowedBooks() == 0) {
				customer.setActive(false);
				OutputWriter.printText("Customer " + customerId + " is succesfully inactivated!");
			} else {
				OutputWriter.printText("Customer " + customerId + " holds " + customer.getNumberOfBorrowedBooks()
						+ " books. Customer can not be inactivated. Please make sure all books are returned before inactivation!");
			}
		} else {
			OutputWriter.printText("Customer " + customerId + " is already inactive!");
		}
	}

	/**
	 * Method to add a new book to library. Method takes a book object as parameter
	 * and add to book catalogue.
	 * 
	 * @param book
	 *            Book object
	 */
	public void addBookToCataloque(Book book) {
		this.bookCatalogue.put(book.getISBN(), book);
		OutputWriter.printText("Book " + book.getISBN() + " is succesfully added!");
	}

	/**
	 * Method to remove a book from book catalogue. Method takes a ISBN string
	 * parameter and remove the books that matches with the ISBN.
	 * 
	 * @param ISBN
	 *            string ISBN
	 */
	public void removeBookFromCataloque(String ISBN) {
		Iterator<Borrowing> borrowedBooksIterator = borrowedBooks.iterator();
		Borrowing borrowedBook = null;
		int bookCounter = 0;
		while (borrowedBooksIterator.hasNext()) {
			borrowedBook = borrowedBooksIterator.next();
			if (borrowedBook.getBook().getISBN().equals(ISBN) && !(borrowedBook.isFinished())) {
				bookCounter++;
			}
		}
		if (bookCounter == 0) {
			this.bookCatalogue.remove(ISBN);
			OutputWriter.printText("Book " + ISBN + " is succesfully removed!");
		} else {
			OutputWriter.printText(bookCounter + " copies of book " + ISBN
					+ " is on customers. Please make sure that all copies returned before removing from catalogue!.");
		}

	}

	/**
	 * Method to borrow books to customer. Method takes customer object and array
	 * list of books as parameter and borrow those books to customer.
	 * 
	 * @param customer
	 *            customer object
	 * @param borrowingBooks
	 *            book arraylist
	 */
	public void borrowBooksToCustomer(Customer customer, ArrayList<Book> borrowingBooks) {
		Iterator<Book> borrowingIterator = borrowingBooks.iterator();
		Book book = null;
		while (borrowingIterator.hasNext()) {
			book = borrowingIterator.next();
			borrowedBooks.add(new Borrowing(book, customer, false, LocalDate.now(),
					LocalDate.now().plusDays(ALLOWED_BORROWING_DURATION)));
			book.decreaseNumberOfAvailableCopies();
			customer.increaseNumberOfBorrowedBooks();
		}
		OutputWriter.printText(
				borrowingBooks.size() + " books is succesfully borrowed to customer " + customer.getCustomerId());
	}

	/**
	 * Method to return books from customer. Method takes customer id string and
	 * ISBN string parameters and return that book from customer
	 * 
	 * @param customerId
	 *            string customer id
	 * @param ISBN
	 *            string ISBN
	 */
	public void returnBooksFromCustomer(String customerId, String ISBN) {
		Iterator<Borrowing> borrowingIterator = borrowedBooks.iterator();
		int returningCounter = 0;
		while (borrowingIterator.hasNext() && returningCounter < 1) {
			Borrowing borrowing = borrowingIterator.next();
			if (borrowing.getCustomer().getCustomerId().equals(customerId) && borrowing.getBook().getISBN().equals(ISBN)
					&& !(borrowing.isFinished())) {
				borrowing.setFinished(true);
				borrowing.getCustomer().decreaseNumberOfBorrowedBooks();
				borrowing.getBook().increaseNumberOfAvailableCopies();
				returningCounter++;
				OutputWriter.printText("Book " + ISBN + " successfully returned.");
			}
		}
		if (returningCounter == 0) {
			OutputWriter.printText(customerId + " does not hold  book " + ISBN + ". Please try another book!");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Library [libraryName=" + libraryName + ", bookCatalogue=" + bookCatalogue + ", customerCatalogue="
				+ customerCatalogue + ", borrowedBooks=" + borrowedBooks + "]";
	}
}
