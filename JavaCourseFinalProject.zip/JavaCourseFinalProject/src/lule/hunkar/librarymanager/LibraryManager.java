package lule.hunkar.librarymanager;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * Driver Class for Library application. Class has library, to create and run
 * the library, and input reader, to get inputs from user, fields. Class has
 * bunch of private helper methods to get inputs and check inputs.
 * 
 * @author Hunkar Lule
 *
 */
public class LibraryManager {
	private static Library library;
	private static InputReader inputReader = new InputReader();

	public static void main(String[] args) {
		OutputWriter.printText("****** Welcome to Library Manager ******\n");

		library = new Library();

		// authors
		Author authorHunkar = new Author("Hunkar", "Lule", LocalDate.of(1980, 10, 10), "hl", Genre.HISTORY);
		Author authorRodrigo = new Author("Rodrigo", "Goncalves", LocalDate.of(1982, 10, 10), "rg", Genre.FICTION);
		Author authorAnil = new Author("Anil", "Gunay", LocalDate.of(1994, 10, 10), "ag", Genre.NON_FICTION);
		Author authorMert = new Author("Mert", "Taskin", LocalDate.of(1980, 10, 10), "mt", Genre.SCI_FI);

		// customers
		Customer customerJohn = new Customer("John", "Hall", LocalDate.of(1975, 10, 10), "AB120", true, 0);
		Customer customerJane = new Customer("Jane", "Doll", LocalDate.of(1955, 10, 10), "AB121", true, 0);
		Customer customerJack = new Customer("Jack", "Mall", LocalDate.of(1962, 10, 10), "AB122", true, 0);
		Customer customerJady = new Customer("Jady", "Pall", LocalDate.of(1995, 10, 10), "AB123", true, 0);
		Customer customerJacy = new Customer("Jacy", "Ball", LocalDate.of(2001, 10, 10), "AB124", true, 0);

		// books
		Book book1 = new Book("History of Canada", authorHunkar, 2001, 3, "123450", Genre.HISTORY, 10, 10);
		Book book2 = new Book("World History", authorHunkar, 2000, 2, "123451", Genre.HISTORY, 8, 8);
		Book book3 = new Book("Deep Java", authorRodrigo, 2005, 1, "123452", Genre.NON_FICTION, 9, 9);
		Book book4 = new Book("Plain Java", authorRodrigo, 2004, 3, "123453", Genre.NON_FICTION, 6, 6);
		Book book5 = new Book("Easy Android", authorRodrigo, 2009, 1, "123454", Genre.NON_FICTION, 9, 9);
		Book book6 = new Book("Story of Stev Jobs", authorAnil, 2001, 3, "123455", Genre.NON_FICTION, 10, 10);
		Book book7 = new Book("Future Robots", authorMert, 2011, 3, "123456", Genre.SCI_FI, 7, 7);

		// a borrowing object to test toString method
		// Borrowing borrowing1 = new Borrowing(book1, customerJack, false,
		// LocalDate.of(2018, 04, 28),
		// LocalDate.of(2018, 04, 28).plusDays(15));

		// adding some books book catalogue
		library.addBookToCataloque(book1);
		library.addBookToCataloque(book2);
		library.addBookToCataloque(book3);
		library.addBookToCataloque(book4);
		library.addBookToCataloque(book5);
		library.addBookToCataloque(book6);
		library.addBookToCataloque(book7);
		// end of adding some books book catalogue

		// adding some customer to customer catalogue
		library.addCustomer(customerJohn);
		library.addCustomer(customerJacy);
		library.addCustomer(customerJack);
		library.addCustomer(customerJady);
		library.addCustomer(customerJane);
		// end of adding some customer to customer catalogue

		// adding some books to borrowings catalogue
		library.borrowBooksToCustomer(customerJack, new ArrayList<Book>() {
			private static final long serialVersionUID = 1L;

			{
				add(book1);
				add(book2);
				add(book5);
			}
		});
		library.borrowBooksToCustomer(customerJacy, new ArrayList<Book>() {
			private static final long serialVersionUID = 1L;

			{
				add(book3);
				add(book4);
			}
		});
		library.borrowBooksToCustomer(customerJady, new ArrayList<Book>() {
			private static final long serialVersionUID = 1L;

			{
				add(book7);
				add(book6);
			}
		});
		library.borrowBooksToCustomer(customerJane, new ArrayList<Book>() {
			private static final long serialVersionUID = 1L;

			{
				add(book3);
				add(book5);
				add(book2);
			}
		}); // end of adding some books to borrowings catalogue

		// testing toString methods for customer, author, book, borrowing and library
		// System.out.println(customerJack);
		// System.out.println("=========================");
		// System.out.println(authorHunkar);
		// System.out.println("=========================");
		// System.out.println(book1);
		// System.out.println("=========================");
		// System.out.println(borrowing1);
		// System.out.println("=========================");
		// System.out.println(library);

		// running library.
		manageLibrary(library);
	}

	private static void manageLibrary(Library library) {
		int operation = -1;
		while (operation != 0) {
			displayOperationsMenu();
			operation = inputReader.getIntInput();
			System.out.println(operation);

			switch (operation) {
			case 1: // to add book to catalogue
				Book book = enterBookDetails();
				library.addBookToCataloque(book);
				library.displayBookCataloque("");
				waitProcessing();
				break;
			case 2: // to remove book from catalogue
				String ISBN = checkbookISBN();
				if (isISBNExist(ISBN)) {
					library.removeBookFromCataloque(ISBN);
				}
				library.displayBookCataloque("");
				waitProcessing();
				break;
			case 3: // to add a customer
				Customer customer = enterCustomerDetails();
				library.addCustomer(customer);
				library.displayCustomerCatalogue();
				waitProcessing();
				break;
			case 4: // to inactivate a customer
				String customerId = checkCustomerId();
				if (isCustomerIdExist(customerId)) {
					library.inactivateCustomer(customerId);
				}
				library.displayCustomerCatalogue();
				waitProcessing();
				break;
			case 5: // to borrow books to a customer
				String bCustomerId = null;
				bCustomerId = checkCustomerId();
				if (isCustomerIdExist(bCustomerId) && isAnActiveCustomer(bCustomerId)) {
					ArrayList<Book> borrowingBooks = enterBorrowingDetails(bCustomerId);
					library.borrowBooksToCustomer(library.getCustomerCatalogue().get(bCustomerId), borrowingBooks);
				}
				waitProcessing();
				break;
			case 6: // to return books from a customer
				String returningCustomerId = null;
				returningCustomerId = checkCustomerId();
				if (isCustomerIdExist(returningCustomerId)) {
					enterReturningBooks(returningCustomerId);
				}
				waitProcessing();
				break;
			case 7: // to list book calatoque
				String sortingChoice = chooseBookSorting();
				OutputWriter.printText("********************Displaying books!**************");
				library.displayBookCataloque(sortingChoice);
				waitProcessing();
				break;
			case 8: // to list customers
				OutputWriter.printText("********************Displaying customers!**************");
				library.displayCustomerCatalogue();
				waitProcessing();
				break;
			case 9: // to list borrowed books
				OutputWriter.printText("********************Displaying borrowings!**************");
				library.displayBorrowings();
				waitProcessing();
				break;
			case 0: // 0 to exit.
				OutputWriter.printText("Program is closing. Please wait!");
				waitProcessing();
				break;
			default:
				OutputWriter.printText("Invalid input. Please try again...");
				break;
			}

		}
		OutputWriter.printText("You quit successfully");
	}

	private static void displayOperationsMenu() {
		OutputWriter.printText("_______Please select an operation________:\n");
		OutputWriter.printText("Add Book                   : Press 1 to add book to catalogue");
		OutputWriter.printText("Remove Book                : Press 2 to remove book from catalogue");
		OutputWriter.printText("Add Customer               : Press 3 to add a customer");
		OutputWriter.printText("Inactive Customer          : Press 4 to inactivate a customer");
		OutputWriter.printText("Borrow Books To Customer   : Press 5 to borrow books to a customer");
		OutputWriter.printText("Return Books From Customer : Press 6 to return books from a customer");
		OutputWriter.printText("List Book Cataloque        : Press 7 to list book calatoque");
		OutputWriter.printText("List Customer Catalogue    : Press 8 to list customers");
		OutputWriter.printText("List Borrowed Books        : Press 9 to list borrowed books");
		OutputWriter.printText("Exit                       : Press 0 to exit.");
		OutputWriter.printText("-------------------------------------------------------------------");
	}

	private static Book enterBookDetails() {
		OutputWriter.printText("please enter book title: ");
		String title = inputReader.getStringInput();
		OutputWriter.printText("please enter author first name: ");
		String firstName = inputReader.getStringInput();
		OutputWriter.printText("please enter author last name: ");
		String lastName = inputReader.getStringInput();
		OutputWriter.printText("please enter author birth date as YYYY-MM-DD: ");
		LocalDate dateOfBirth = getPersonBirthDate();
		OutputWriter.printText("please enter author pseudonym: ");
		String pseudonym = inputReader.getStringInput();
		OutputWriter.printText("please enter author speciality: ");
		Genre specialty = checkGenre();
		int publishedYear = 0;
		do {
			OutputWriter.printText("please enter publish year: ");
			publishedYear = inputReader.getIntInput();

		} while (publishedYear < 1600 || publishedYear > 2018);
		int edition = -1;
		do {
			OutputWriter.printText("please enter book edition: ");
			edition = inputReader.getIntInput();

		} while (edition < 1);

		OutputWriter.printText("please enter book ISBN: ");
		String ISBN = checkbookISBN();
		OutputWriter.printText("please enter book genre: ");
		Genre genre = checkGenre();
		OutputWriter.printText("please enter number of copies: ");
		int numberOfCopies = inputReader.getIntInput();
		return new Book(title, new Author(firstName, lastName, dateOfBirth, pseudonym, specialty), publishedYear,
				edition, ISBN, genre, numberOfCopies, numberOfCopies);
	}

	private static Customer enterCustomerDetails() {
		String customerId = checkCustomerId();
		OutputWriter.printText("please enter customer first name: ");
		String firstName = inputReader.getStringInput();
		OutputWriter.printText("please enter customer last name: ");
		String lastName = inputReader.getStringInput();
		OutputWriter.printText("please enter customer birth date as YYYY-MM-DD: ");
		LocalDate dateOfBirth = getPersonBirthDate();
		return new Customer(firstName, lastName, dateOfBirth, customerId, true, 0);
	}

	private static ArrayList<Book> enterBorrowingDetails(String customerId) {
		ArrayList<Book> books = new ArrayList<>();
		boolean addMoreBooks = true;
		int bookCount = library.getCustomerCatalogue().get(customerId).getNumberOfBorrowedBooks() + books.size();
		if (bookCount >= Library.CUSTOMER_BOOK_BOORWING_LIMIT) {
			OutputWriter.printText("Customer " + customerId + " alreay holds maximum number of books("
					+ Library.CUSTOMER_BOOK_BOORWING_LIMIT + "). The customer can not borrow more!");
		}
		while (bookCount < Library.CUSTOMER_BOOK_BOORWING_LIMIT && addMoreBooks) {
			String ISBN = checkbookISBN();
			if (isISBNExist(ISBN)) {
				Book newBook = library.getBookCatalogue().get(ISBN);
				books.add(newBook);
				bookCount++;
				OutputWriter.printText("Do you want to add more books(Please enter 'Y' for yes and any-key for 'No'):");
				String answer = inputReader.getStringInput();
				if (!(answer.equalsIgnoreCase("Y"))) {
					addMoreBooks = false;
				}
			}
			if (bookCount >= Library.CUSTOMER_BOOK_BOORWING_LIMIT && addMoreBooks) {
				OutputWriter.printText("Customer " + customerId + " has reached boorwing limit "
						+ Library.CUSTOMER_BOOK_BOORWING_LIMIT + ". The customer can not borrow more!");
			}
		}
		return books;
	}

	private static void enterReturningBooks(String customerId) {
		boolean returnMoreBooks = true;
		do {
			String returningbookISBN = checkbookISBN();
			if (isISBNExist(returningbookISBN)) {
				library.returnBooksFromCustomer(customerId, returningbookISBN);
			}

			OutputWriter.printText(
					"Is there more books to return? Please press 'Y' for 'Yes' and press 'any key' for 'No': ");
			String answer = inputReader.getStringInput();
			if (!answer.equalsIgnoreCase("Y")) {
				returnMoreBooks = false;
			}

		} while (returnMoreBooks);
	}

	private static String checkbookISBN() {
		String bookISBN = "";
		boolean isValidISBN = false;
		do {
			OutputWriter.printText("please enter book ISBN. It should consist of 6 digits[0-9]");
			bookISBN = inputReader.getStringInput();
			if (!bookISBN.matches("\\d{6}")) {
				OutputWriter.printText("ISBN is not valid. Please try again!");
			} else {
				isValidISBN = true;
			}
		} while (!isValidISBN);
		return bookISBN;
	}

	private static LocalDate getPersonBirthDate() {
		String birthDate = "";
		boolean isValidDate = false;
		boolean isValidDay = false;
		LocalDate dateOfBirth = null;
		String[] splittedBirthDate;

		do {
			birthDate = inputReader.getStringInput();
			isValidDate = checkDate(birthDate);
			if (isValidDate) {
				splittedBirthDate = birthDate.split("-");
				isValidDay = checkValidDate(Integer.parseInt(splittedBirthDate[0]),
						Integer.parseInt(splittedBirthDate[1]), Integer.parseInt(splittedBirthDate[2]));
				if (isValidDay) {
					String formattedBirthDate = splittedBirthDate[0] + splittedBirthDate[1] + splittedBirthDate[2];
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
					dateOfBirth = LocalDate.parse(formattedBirthDate, formatter);
				} else
					OutputWriter.printText("Date is invalid.Please enter valid date as YYYY-MM-DD: ");
			} else
				OutputWriter.printText("Date is invalid.Please enter valid date as YYYY-MM-DD: ");

		} while (isValidDate == false || isValidDay == false);

		return dateOfBirth;
	}

	private static boolean checkDate(String birthDate) {
		if (!birthDate.matches(
				"([1][7-9][0-9]{2}|((200)[0-9]|(201)[1-7]|))[-]([0]?[1-9]|[1][0-2]|)[-]([0]?[1-9]|[1-2][0-9]|[3][0-1])$")) {
			return false;
		}
		return true;
	}

	private static boolean checkValidDate(int year, int month, int day) {
		switch (month) {
		case 4:
		case 6:
		case 9:
		case 11:
			if (day == 31) {
				return false;
			}
		case 2:
			if ((year % 4 != 0) || (year % 100 == 0 && year % 400 != 0)) {
				if (day > 28)
					return false;
			} else if (day > 29)
				return false;
		}

		return true;
	}

	private static Genre checkGenre() {
		boolean isValidGenre = false;
		String genre;
		Genre result = Genre.FICTION;
		do {
			genre = inputReader.getStringInput();
			for (Genre genres : Genre.values()) {
				if (genres.name().equalsIgnoreCase(genre)) {
					result = Genre.valueOf(genres.name());
					isValidGenre = true;
				}
			}
			if (!isValidGenre) {
				OutputWriter.printText("Input is invalid. Please enter one of the values: " + Genre.genresString());
			}
		} while (!isValidGenre);
		return result;
	}

	private static String checkCustomerId() {
		String customerId = "";
		boolean isValidId = false;
		do {
			OutputWriter.printText("please enter customer id(eg.'AB123'): ");
			customerId = inputReader.getStringInput();
			if (!customerId.matches("[A-Za-z]{2}[0-9]{3}")) {
				OutputWriter.printText("Customer id is not valid. Please try again!");
			} else {
				isValidId = true;
			}
		} while (!isValidId);
		return customerId.toUpperCase();
	}

	private static void waitProcessing() {
		try {
			OutputWriter.printText("Processing please wait!");
			Thread.sleep(500);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}

	private static boolean isCustomerIdExist(String customerId) {
		boolean result = library.getCustomerCatalogue().containsKey(customerId);
		if (!result) {
			OutputWriter.printText("Customer " + customerId + " does not exist in the system. Please try again!");
		}
		return result;
	}

	private static boolean isAnActiveCustomer(String customerId) {
		boolean result = library.getCustomerCatalogue().get(customerId).isActive();
		if (!result) {
			OutputWriter.printText("Customer " + customerId + " is inactive. Customer can not borrow books!");
		}
		return result;
	}

	private static boolean isISBNExist(String ISBN) {
		boolean result = library.getBookCatalogue().containsKey(ISBN);
		if (!result) {
			OutputWriter.printText("Book " + ISBN + " does not exist in the system. Please try again!");
		}
		return result;
	}

	private static String chooseBookSorting() {
		String sortingOption = "";
		OutputWriter.printText("Please choose sorting option:\n" + "To sort  with 'Edition' press 'E'\n"
				+ "To sort  with 'Publised year' press 'P'\n" + "For not sorting press 'any key except P or E'");
		sortingOption = inputReader.getStringInput();
		return sortingOption.toUpperCase();
	}
}