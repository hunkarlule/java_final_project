package lule.hunkar.librarymanager;

/**
 * Helper Class to write output to console. It has only one method.
 * 
 * @author Hunkar Lule
 * 
 */
public class OutputWriter {
	public static void printText(String text) {
		System.out.println(text);
	}
}
